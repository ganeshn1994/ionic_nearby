export class MapLocations {
    geometry: Object;
    icon: String;
    id: String;
    name: String;
    opening_hours: Object;
    photos: Array<any>;
    place_id: String;
    rating: Number;
    reference: String;
    scope: String;
    types: Array<any>;
    vicinity: String;
}