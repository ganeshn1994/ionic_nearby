import { Injectable } from '@angular/core';
import { MapLocations } from './map.locations';

//@Injectable()

declare var google: any;

export class MapsServices {

    mapObj: any;
    mapServiceObj: any;
    public _locations: MapLocations[];

    restaurantsNearMe(restaurants): any{
        var map = new google.maps.Map("", {});

        var service = new google.maps.places.PlacesService(map);
        return new Promise(function(resolve,reject){ 
            service.nearbySearch({
            location: {lat: 17.4484363, lng: 78.374136},
            radius: 500,
            keyword: 'food',
            type: ['restaurants']
            }, (results, status) => {
                if (status === google.maps.places.PlacesServiceStatus.OK) {
                    //this._locations = results as MapLocations[];
                    resolve(results);
                }else{
                    reject(status);
                }
            });
        });
    }
}