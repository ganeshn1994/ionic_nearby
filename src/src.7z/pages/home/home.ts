import { Component, OnInit, NgZone, AfterViewInit  } from '@angular/core';
import { NgForOf } from '@angular/common';
import { NavController } from 'ionic-angular';
import { MapsServices } from '../../app/maps/maps.services';
import { Jsonp, HttpModule, JSONPConnection, JsonpModule } from '@angular/http';
import { MapLocations } from '../../app/maps/map.locations';

import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Rx';


@Component({
    selector: 'page-home',
    templateUrl: 'home.html',
    providers: [
      Jsonp,
      JsonpModule,
      HttpModule
    ]
})
export class HomePage {

    public restaurants: MapLocations[];
    private results: Observable<any>;
    constructor(public navCtrl: NavController, private mapsServices: MapsServices) {}

    getRestaurantsNearMe(): void{
        let mapApi = this.mapsServices.restaurantsNearMe(this.restaurants);
        mapApi.then((results)=>{
          this.restaurants = results as MapLocations[];
          console.log(results);
        });
    }

    ngAfterViewInit() {
        //console.log("okokok+1111");
        this.getRestaurantsNearMe();
    }


}
