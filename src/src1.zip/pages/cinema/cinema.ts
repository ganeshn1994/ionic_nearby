import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-cinema',
  templateUrl: 'cinema.html'
})
export class CinemaPage {

  constructor(public navCtrl: NavController) {

  }

}
