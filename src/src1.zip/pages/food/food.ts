import { Component, OnInit, NgZone, AfterViewInit  } from '@angular/core';
import { NgForOf, AsyncPipe  } from '@angular/common';
import { NavController } from 'ionic-angular';
import { MapsServices } from '../../app/maps/maps.services';
import { HttpModule } from '@angular/http';
import { MapLocations } from '../../app/maps/map.locations';
import { Geolocation } from '@ionic-native/geolocation';


import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Rx';


@Component({
    selector: 'page-food',
    templateUrl: 'food.html',
    providers: [
      HttpModule
    ]
})
export class FoodPage {

    public restaurants: MapLocations[];
    private results: Observable<any>;
    constructor(public navCtrl: NavController, private mapsServices: MapsServices, private geolocation: Geolocation) {}

    getRestaurantsNearMe(): void{
        let mapApi = this.mapsServices.restaurantsNearMe(this.restaurants);
        mapApi.then((results)=>{
            console.log(results);
            this.restaurants = results as MapLocations[];
        });
    }

    ngAfterViewInit() {

        // var a = new Promise((resolve,reject)=> { 
        //     setTimeout(resolve, 3000);
        // });

        // a.then( () =>{
        //     this.mapsServices.lat = 17.4484363;
        //     this.mapsServices.log = 78.374136;
        //     this.getRestaurantsNearMe();
        // });


        this.geolocation.getCurrentPosition().then((resp) => {
            this.mapsServices.lat = resp.coords.latitude;
            this.mapsServices.log = resp.coords.longitude;
            this.getRestaurantsNearMe();
        }).catch((error) => {
            console.log('Error getting location', error);
        });


        //console.log("okokok+1111");
        //this.getRestaurantsNearMe();
    }


}
