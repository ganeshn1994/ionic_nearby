import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-fun',
  templateUrl: 'fun.html'
})
export class FunPage {

  constructor(public navCtrl: NavController) {

  }

}
